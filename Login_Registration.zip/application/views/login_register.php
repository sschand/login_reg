<!DOCTYPE html>
<html>
<head>
	<title>Login and Registration</title>
	<link rel="stylesheet" type="text/css" href="/assets/css/skeleton.css">
	<style type="text/css" media="screen">
		span{
			margin: 0px 3em;
		}
		.green{
			color: green;
		}
		.red{
			color: red;
		}
		.section{
			border: .2em solid black;
			margin-top: 3em;
			padding: 1%;
		}
		.login_row,.register_row{
			margin-right: 8.5em;
			float: right;
		}
		#register_block{
			padding: 0% 10%;
		}
		p{
			color: red;
		}
		h2#register{
		    width: 17%;
		    margin-top: -5%;
		    background: white;
		    padding: .1em;
		}
		h2#log{
		    width: 13%;
		    margin-top: -5%;
		    background: white;
		    padding: .1em;
		}
	</style>
</head>
<body>
<div class="wrapper">	
	<div class="container">
		<?php echo $this->session->flashdata('error');?>
	</div>
		
	<div class="container section">
		<h2 id="log">Log In</h2>
		<form action="/login/log_in" method="post">
			<div class="container">
				<?php echo form_error('log_email'); ?>
				<div class="row">
					<div class="two columns">
						<label for="log_email">Email:</label>
					</div>
					<div class="eight columns">
						<input type="text" name="log_email" class="u-full-width">
					</div>		
					<div class="two columns"></div>		
				</div>	
				<?php echo form_error('log_password'); ?>
				<div class="row">
					<div class="two columns">
						<label for="log_password">Password:</label>
					</div>
					<div class="eight columns">
						<input type="password" name="log_password" class="u-full-width">
					</div>	
					<div class="two columns"></div>				
				</div>	
				<div class="row login_row">
					<button type="submit" class="button-primary">Login</button>				
				</div>
			</div>
		</form>		
	</div>
	
	<div class="container section">
		<h2 id="register">Register</h2>	
		<form action="/login/register" method="post">
			<div id="register_block">
				<div class="row">
					<div class="three columns">
						<label for="first_name">First Name:</label>
					</div>
					<div class="seven columns">
						<input type="text" name="first_name" class="u-full-width">
					</div>		
					<div class="two columns"></div>		
				</div>	
				<div class="row">
					<div class="three columns">
						<label for="last_name">Last Name:</label>
					</div>
					<div class="seven columns">
						<input type="text" name="last_name" class="u-full-width">
					</div>		
					<div class="two columns"></div>		
				</div>	
				<?php echo form_error('email'); ?>
				<div class="row">
					<div class="three columns">
						<label for="email">Email Address:</label>
					</div>
					<div class="seven columns">
						<input type="text" name="email" class="u-full-width">
					</div>		
					<div class="two columns"></div>		
				</div>	
				<?php echo form_error('password'); ?>
				<div class="row">
					<div class="three columns">
						<label for="password">Password:</label>
					</div>
					<div class="seven columns">
						<input type="password" name="password" class="u-full-width">
					</div>		
					<div class="two columns"></div>		
				</div>	
				<?php echo form_error('c_password'); ?>
				<div class="row">
					<div class="three columns">
						<label for="c_password">Confirm Password:</label>
					</div>
					<div class="seven columns">
						<input type="password" name="c_password" class="u-full-width">
					</div>		
					<div class="two columns"></div>		
				</div>

				<div class="row register_row">
					<button type="submit" class="button-primary">Register</button>				
				</div>
			</div>
		</form>			
	</div>
</div>
</body>
</html>