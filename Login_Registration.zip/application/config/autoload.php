<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$autoload['packages'] = array();

$autoload['libraries'] = array('database','session','form_validation');

$autoload['helper'] = array('url','text','string','date','form');

$autoload['config'] = array();

$autoload['language'] = array();

$autoload['model'] = array();

//end of autoload.php